const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const jwt = require('jsonwebtoken');

// ==================== Mock Data Storage ====================
const users = new Map();
const sessions = new Map();
const conversions = new Map();
const storageQuotas = new Map();

const JWT_SECRET = 'your-secret-key-change-in-production';
const REFRESH_SECRET = 'your-refresh-secret-key';
const DEFAULT_STORAGE_BYTES = 5 * 1024 * 1024 * 1024; // 5GB

const SUPPORTED_FORMATS = ['scorm1.2', 'scorm2004', 'moodle', 'edx', 'opale', 'pdf', 'h5p'];

// ==================== Middleware ====================
const verifyToken = (req, res, next) => {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Token مفقود' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.userId = decoded.userId;
    next();
  } catch (err) {
    return res.status(403).json({ error: 'Token غير صحيح' });
  }
};

const hashPassword = (password) => {
  // محاكاة بسيطة - في الإنتاج استخدم bcrypt
  return Buffer.from(password).toString('base64');
};

const generateTokens = (userId) => {
  const token = jwt.sign({ userId }, JWT_SECRET, { expiresIn: '1h' });
  const refreshToken = jwt.sign({ userId }, REFRESH_SECRET, { expiresIn: '7d' });
  return { token, refreshToken };
};

// ==================== Auth Endpoints ====================
router.post('/auth/register', (req, res) => {
  const { email, password, full_name, language = 'ar' } = req.body;

  if (!email || !password || !full_name) {
    return res.status(400).json({ error: 'البيانات المطلوبة ناقصة' });
  }

  if (Array.from(users.values()).some(u => u.email === email)) {
    return res.status(409).json({ error: 'البريد الإلكتروني موجود بالفعل' });
  }

  const userId = uuidv4();
  const user = {
    id: userId,
    email,
    password_hash: hashPassword(password),
    full_name,
    language,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    is_active: true
  };

  users.set(userId, user);

  // إنشاء حصة التخزين الافتراضية
  storageQuotas.set(userId, {
    id: uuidv4(),
    user_id: userId,
    max_storage_bytes: DEFAULT_STORAGE_BYTES,
    used_storage_bytes: 0,
    updated_at: new Date().toISOString()
  });

  res.status(201).json({
    message: 'تم إنشاء الحساب بنجاح',
    user: {
      id: user.id,
      email: user.email,
      full_name: user.full_name,
      language: user.language
    }
  });
});

router.post('/auth/login', (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'البريد والكلمة المرورية مطلوبة' });
  }

  const user = Array.from(users.values()).find(u => u.email === email);

  if (!user || user.password_hash !== hashPassword(password)) {
    return res.status(401).json({ error: 'بيانات الدخول غير صحيحة' });
  }

  if (!user.is_active) {
    return res.status(403).json({ error: 'الحساب معطل' });
  }

  const { token, refreshToken } = generateTokens(user.id);

  const session = {
    id: uuidv4(),
    user_id: user.id,
    token,
    refresh_token: refreshToken,
    expires_at: new Date(Date.now() + 3600000).toISOString(),
    created_at: new Date().toISOString()
  };

  sessions.set(session.id, session);

  res.json({
    token,
    refreshToken,
    user: {
      id: user.id,
      email: user.email,
      full_name: user.full_name,
      language: user.language
    }
  });
});

router.post('/auth/refresh', (req, res) => {
  const { refreshToken } = req.body;

  if (!refreshToken) {
    return res.status(400).json({ error: 'Refresh token مطلوب' });
  }

  try {
    const decoded = jwt.verify(refreshToken, REFRESH_SECRET);
    const { token, refreshToken: newRefreshToken } = generateTokens(decoded.userId);

    res.json({ token, refreshToken: newRefreshToken });
  } catch (err) {
    res.status(403).json({ error: 'Refresh token غير صحيح' });
  }
});

router.post('/auth/logout', verifyToken, (req, res) => {
  const session = Array.from(sessions.values()).find(s => s.user_id === req.userId);
  if (session) {
    sessions.delete(session.id);
  }

  res.json({ message: 'تم تسجيل الخروج بنجاح' });
});

// ==================== Conversion Endpoints ====================
router.post('/convert', verifyToken, (req, res) => {
  const { source_format, target_format, conversion_options = {} } = req.body;

  if (!source_format || !target_format) {
    return res.status(400).json({ error: 'صيغة المصدر والهدف مطلوبة' });
  }

  if (!SUPPORTED_FORMATS.includes(source_format) || !SUPPORTED_FORMATS.includes(target_format)) {
    return res.status(400).json({ error: 'صيغة غير مدعومة' });
  }

  const conversionId = uuidv4();
  const conversion = {
    id: conversionId,
    user_id: req.userId,
    source_format,
    target_format,
    source_file_name: 'sample_file',
    target_file_name: `converted_${Date.now()}`,
    source_file_size: 1024 * 500, // 500 KB
    target_file_size: null,
    status: 'processing',
    error_message: null,
    conversion_options,
    processing_time_ms: 0,
    created_at: new Date().toISOString(),
    completed_at: null,
    download_count: 0
  };

  conversions.set(conversionId, conversion);

  // محاكاة معالجة غير متزامنة
  setTimeout(() => {
    const conv = conversions.get(conversionId);
    conv.status = 'completed';
    conv.target_file_size = 1024 * 450;
    conv.processing_time_ms = 2500;
    conv.completed_at = new Date().toISOString();
  }, 2500);

  res.status(202).json({
    message: 'بدأت عملية التحويل',
    conversion: {
      id: conversion.id,
      status: conversion.status,
      created_at: conversion.created_at
    }
  });
});

router.post('/convert/batch', verifyToken, (req, res) => {
  const { files } = req.body;

  if (!Array.isArray(files) || files.length === 0) {
    return res.status(400).json({ error: 'قائمة الملفات مطلوبة' });
  }

  const batchConversions = files.map(file => {
    const conversionId = uuidv4();
    const conversion = {
      id: conversionId,
      user_id: req.userId,
      source_format: file.source_format,
      target_format: file.target_format,
      source_file_name: file.file_name,
      target_file_name: `converted_${conversionId}`,
      source_file_size: file.file_size || 0,
      target_file_size: null,
      status: 'pending',
      error_message: null,
      conversion_options: file.options || {},
      processing_time_ms: 0,
      created_at: new Date().toISOString(),
      completed_at: null,
      download_count: 0
    };

    conversions.set(conversionId, conversion);
    return conversion;
  });

  res.status(202).json({
    message: 'بدأت عمليات التحويل الجماعية',
    conversions: batchConversions.map(c => ({
      id: c.id,
      status: c.status
    }))
  });
});

router.get('/convert/:conversionId', verifyToken, (req, res) => {
  const conversion = conversions.get(req.params.conversionId);

  if (!conversion) {
    return res.status(404).json({ error: 'التحويل غير موجود' });
  }

  if (conversion.user_id !== req.userId) {
    return res.status(403).json({ error: 'غير مصرح' });
  }

  res.json(conversion);
});

router.get('/convert/:conversionId/download', verifyToken, (req, res) => {
  const conversion = conversions.get(req.params.conversionId);

  if (!conversion) {
    return res.status(404).json({ error: 'التحويل غير موجود' });
  }

  if (conversion.user_id !== req.userId) {
    return res.status(403).json({ error: 'غير مصرح' });
  }

  if (conversion.status !== 'completed') {
    return res.status(400).json({ error: 'التحويل لم يكتمل بعد' });
  }

  conversion.download_count += 1;

  res.setHeader('Content-Disposition', `attachment; filename="${conversion.target_file_name}"`);
  res.setHeader('Content-Type', 'application/octet-stream');
  res.send(Buffer.from('Mock file content'));
});

router.get('/conversions', verifyToken, (req, res) => {
  const { page = 1, limit = 10, status, source_format, target_format } = req.query;

  let userConversions = Array.from(conversions.values()).filter(c => c.user_id === req.userId);

  if (status) {
    userConversions = userConversions.filter(c => c.status === status);
  }
  if (source_format) {
    userConversions = userConversions.filter(c => c.source_format === source_format);
  }
  if (target_format) {
    userConversions = userConversions.filter(c => c.target_format === target_format);
  }

  const pageNum = Math.max(1, parseInt(page));
  const limitNum = Math.max(1, Math.min(100, parseInt(limit)));
  const startIdx = (pageNum - 1) * limitNum;
  const endIdx = startIdx + limitNum;

  const paginatedConversions = userConversions.slice(startIdx, endIdx);

  res.json({
    data: paginatedConversions,
    pagination: {
      page: pageNum,
      limit: limitNum,
      total: userConversions.length,
      pages: Math.ceil(userConversions.length / limitNum)
    }
  });
});

router.delete('/conversions/:conversionId', verifyToken, (req, res) => {
  const conversion = conversions.get(req.params.conversionId);

  if (!conversion) {
    return res.status(404).json({ error: 'التحويل غير موجود' });
  }

  if (conversion.user_id !== req.userId) {
    return res.status(403).json({ error: 'غير مصرح' });
  }

  const quota = storageQuotas.get(req.userId);
  if (quota && conversion.target_file_size) {
    quota.used_storage_bytes = Math.max(0, quota.used_storage_bytes - conversion.target_file_size);
    quota.updated_at = new Date().toISOString();
  }

  conversions.delete(req.params.conversionId);

  res.json({ message: 'تم حذف التحويل بنجاح' });
});

// ==================== User Endpoints ====================
router.get('/user/profile', verifyToken, (req, res) => {
  const user = users.get(req.userId);

  if (!user) {
    return res.status(404).json({ error: 'المستخدم غير موجود' });
  }

  res.json({
    id: user.id,
    email: user.email,
    full_name: user.full_name,
    language: user.language,
    is_active: user.is_active,
    created_at: user.created_at,
    updated_at: user.updated_at
  });
});

router.put('/user/profile', verifyToken, (req, res) => {
  const user = users.get(req.userId);

  if (!user) {
    return res.status(404).json({ error: 'المستخدم غير موجود' });
  }

  const { full_name, language } = req.body;

  if (full_name) user.full_name = full_name;
  if (language && ['ar', 'en'].includes(language)) user.language = language;

  user.updated_at = new Date().toISOString();

  res.json({
    message: 'تم تحديث الملف الشخصي',
    user: {
      id: user.id,
      email: user.email,
      full_name: user.full_name,
      language: user.language
    }
  });
});

router.get('/user/statistics', verifyToken, (req, res) => {
  const userConversions = Array.from(conversions.values()).filter(c => c.user_id === req.userId);
  const completedConversions = userConversions.filter(c => c.status === 'completed');
  const failedConversions = userConversions.filter(c => c.status === 'failed');

  const totalProcessingTime = completedConversions.reduce((sum, c) => sum + c.processing_time_ms, 0);
  const totalDownloads = userConversions.reduce((sum, c) => sum + c.download_count, 0);

  res.json({
    total_conversions: userConversions.length,
    completed_conversions: completedConversions.length,
    failed_conversions: failedConversions.length,
    pending_conversions: userConversions.filter(c => c.status === 'pending').length,
    total_processing_time_ms: totalProcessingTime,
    average_processing_time_ms: completedConversions.length > 0 ? Math.round(totalProcessingTime / completedConversions.length) : 0,
    total_downloads: totalDownloads
  });
});

router.get('/user/storage-quota', verifyToken, (req, res) => {
  const quota = storageQuotas.get(req.userId);

  if (!quota) {
    return res.status(404).json({ error: 'حصة التخزين غير موجودة' });
  }

  const usedPercent = Math.round((quota.used_storage_bytes / quota.max_storage_bytes) * 100);

  res.json({
    max_storage_bytes: quota.max_storage_bytes,
    used_storage_bytes: quota.used_storage_bytes,
    available_storage_bytes: quota.max_storage_bytes - quota.used_storage_bytes,
    used_percent: usedPercent,
    updated_at: quota.updated_at
  });
});

// ==================== Formats Endpoints ====================
router.get('/formats/supported', (req, res) => {
  const conversions_matrix = {};

  SUPPORTED_FORMATS.forEach(source => {
    conversions_matrix[source] = SUPPORTED_FORMATS.filter(target => target !== source);
  });

  res.json({
    formats: SUPPORTED_FORMATS,
    conversions_matrix
  });
});

router.get('/formats/:format/options', (req, res) => {
  const { format } = req.params;

  if (!SUPPORTED_FORMATS.includes(format)) {
    return res.status(404).json({ error: 'الصيغة غير مدعومة' });
  }

  const optionsMap = {
    scorm1.2: [
      { key: 'include_metadata', type: 'boolean', default: true },
      { key: 'compress', type: 'boolean', default: false }
    ],
    scorm2004: [
      { key: 'include_metadata', type: 'boolean', default: true },
      { key: 'sequencing', type: 'boolean', default: true }
    ],
    moodle: [
      { key: 'backup_format', type: 'string', default: 'xml' },
      { key: 'include_activities', type: 'boolean', default: true }
    ],
    edx: [
      { key: 'include_discussions', type: 'boolean', default: true },
      { key: 'include_certificates', type: 'boolean', default: false }
    ],
    opale: [
      { key: 'template', type: 'string', default: 'default' }
    ],
    pdf: [
      { key: 'quality', type: 'enum: low|medium|high', default: 'high' },
      { key: 'include_metadata', type: 'boolean', default: false }
    ],
    h5p: [
      { key: 'export_format', type: 'string', default: 'standalone' }
    ]
  };

  res.json({
    format,
    options: optionsMap[format] || []
  });
});

module.exports = router;