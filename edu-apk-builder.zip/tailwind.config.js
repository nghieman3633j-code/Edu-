/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: { primary: "#0f172a" },
      fontFamily: { sans: ["Inter, Tajawal", "system-ui", "sans-serif"] },
    },
  },
  plugins: [],
};
