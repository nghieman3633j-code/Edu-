export default function Home() {
  return (
    <div className="min-h-screen bg-slate-950 text-white font-[family-name:var(--font-geist-sans)]">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-slate-950/95 backdrop-blur border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="text-2xl font-bold bg-gradient-to-r from-blue-500 to-blue-600 bg-clip-text text-transparent">
            ConvertHub
          </div>
          <button className="px-6 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg font-semibold transition-colors">
            ابدأ الآن
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative px-4 sm:px-6 lg:px-8 py-20 sm:py-32 max-w-7xl mx-auto">
        <div className="text-center space-y-8">
          <div className="inline-block px-4 py-2 bg-blue-600/20 border border-blue-500/50 rounded-full">
            <span className="text-blue-300 text-sm font-semibold">🚀 تحويل ملفات احترافي</span>
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight">
            حوّل ملفاتك بسهولة <span className="block bg-gradient-to-r from-blue-500 via-blue-600 to-green-500 bg-clip-text text-transparent"> إلى أي صيغة تريد </span>
          </h1>
          <p className="text-lg sm:text-xl text-slate-400 max-w-2xl mx-auto leading-relaxed">
            منصة متقدمة لتحويل الملفات بين صيغ متعددة. دعم فوري لأكثر من 50 صيغة مع ضمان الأمان والجودة العالية
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
            <button className="px-8 py-4 bg-blue-600 hover:bg-blue-700 rounded-lg font-semibold text-lg transition-all transform hover:scale-105 shadow-lg shadow-blue-600/50">
              ابدأ التحويل المجاني
            </button>
            <button className="px-8 py-4 border border-slate-600 hover:border-slate-400 rounded-lg font-semibold text-lg transition-colors">
              اعرف المزيد
            </button>
          </div>
        </div>
      </section>

      {/* Supported Formats */}
      <section className="px-4 sm:px-6 lg:px-8 py-16 sm:py-24 bg-slate-900/50 border-y border-slate-800">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-bold text-center mb-4">الصيغ المدعومة</h2>
          <p className="text-slate-400 text-center mb-12 max-w-2xl mx-auto">
            ندعم تحويل شامل بين جميع الصيغ الشهيرة والاحترافية
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            {['PDF', 'JPG', 'PNG', 'DOCX', 'XLSX', 'MP4', 'MP3', 'WebP', 'SVG', 'GIF', 'TIFF', 'ZIP'].map((format) => (
              <div key={format} className="p-4 bg-slate-800 hover:bg-slate-700 rounded-lg text-center transition-colors border border-slate-700 hover:border-blue-500">
                <span className="font-semibold text-blue-400">{format}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="px-4 sm:px-6 lg:px-8 py-16 sm:py-24 max-w-7xl mx-auto">
        <h2 className="text-3xl sm:text-4xl font-bold text-center mb-16">ميزات المنصة</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {[
            { icon: '⚡', title: 'تحويل فوري', desc: 'معالجة سريعة وآمنة للملفات في ثوانٍ معدودة' },
            { icon: '🔒', title: 'أمان عالي', desc: 'تشفير end-to-end وحذف فوري للملفات بعد التحويل' },
            { icon: '📊', title: 'جودة عالية', desc: 'الحفاظ على جودة المحتوى والدقة في كل تحويل' },
            { icon: '🌐', title: 'بدون تثبيت', desc: 'منصة ويب مباشرة - لا تحتاج لتثبيت أي برامج' },
            { icon: '📱', title: 'متوافق', desc: 'يعمل على جميع الأجهزة والمتصفحات بسلاسة' },
            { icon: '♾️', title: 'بلا حدود', desc: 'حول ملفات غير محدودة بدون قيود أو اشتراكات' },
          ].map((feature, idx) => (
            <div key={idx} className="p-6 bg-slate-900 border border-slate-800 rounded-lg hover:border-blue-600 transition-colors group">
              <div className="text-4xl mb-4 group-hover:scale-110 transition-transform">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-slate-400">{feature.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* How It Works */}
      <section className="px-4 sm:px-6 lg:px-8 py-16 sm:py-24 bg-slate-900/50 border-y border-slate-800">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-bold text-center mb-16">كيفية الاستخدام</h2>
          <div className="space-y-8">
            {[
              { num: 1, title: 'اختر ملفك', desc: 'انقر لاختيار الملف من جهازك أو اسحبه مباشرة' },
              { num: 2, title: 'حدد الصيغة', desc: 'اختر الصيغة المطلوبة من القائمة المتاحة' },
              { num: 3, title: 'ابدأ التحويل', desc: 'انقر زر التحويل واستمتع بالنتيجة الفورية' },
              { num: 4, title: 'حمّل الملف', desc: 'احصل على ملفك المحول جاهزاً للتحميل' },
            ].map((step, idx) => (
              <div key={idx} className="flex gap-6 items-start">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-600 to-blue-700 flex items-center justify-center font-bold text-lg flex-shrink-0">
                  {step.num}
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
                  <p className="text-slate-400">{step.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="px-4 sm:px-6 lg:px-8 py-20 sm:py-32 max-w-7xl mx-auto text-center">
        <div className="space-y-8">
          <h2 className="text-4xl sm:text-5xl font-bold"> جاهز لتحويل ملفاتك؟ </h2>
          <p className="text-xl text-slate-400 max-w-2xl mx-auto"> انضم لآلاف المستخدمين الذين يثقون بـ ConvertHub يومياً </p>
          <button className="px-10 py-5 bg-gradient-to-r from-blue-600 to-green-500 hover:from-blue-700 hover:to-green-600 rounded-lg font-bold text-lg transition-all transform hover:scale-105 shadow-xl shadow-blue-600/50">
            ابدأ الآن مجاناً
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-800 bg-slate-900/50 px-4 sm:px-6 lg:px-8 py-12">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="text-xl font-bold text-blue-400 mb-4">ConvertHub</div>
              <p className="text-slate-400 text-sm">منصة تحويل ملفات احترافية وموثوقة</p>
            </div>
            {[
              { title: 'المنتج', links: ['الميزات', 'الأسعار', 'الأمان'] },
              { title: 'الشركة', links: ['حول', 'المدونة', 'الوظائف'] },
              { title: 'القانون', links: ['الخصوصية', 'الشروط', 'الاتصال'] },
            ].map((col, idx) => (
              <div key={idx}>
                <h4 className="font-semibold mb-4">{col.title}</h4>
                <ul className="space-y-2">
                  {col.links.map((link) => (
                    <li key={link} className="text-slate-400 hover:text-blue-400 cursor-pointer transition-colors text-sm">
                      {link}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
          <div className="border-t border-slate-800 pt-8 text-center text-slate-400 text-sm">
            <p>© 2024 ConvertHub. جميع الحقوق محفوظة.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}