import React, { useState } from 'react';
import { BarChart3, FileText, History, Settings, LogOut, ArrowUpRight, ArrowDownLeft, Zap, Download, Share2, Trash2, Plus, TrendingUp } from 'lucide-react';

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState('overview');
  const [conversions, setConversions] = useState([
    { id: 1, from: 'PDF', to: 'Word', date: '2024-01-15', size: '2.4 MB', status: 'success' },
    { id: 2, from: 'Image', to: 'PDF', date: '2024-01-14', size: '1.8 MB', status: 'success' },
    { id: 3, from: 'Video', to: 'MP3', date: '2024-01-13', size: '45 MB', status: 'failed' },
    { id: 4, from: 'Excel', to: 'CSV', date: '2024-01-12', size: '890 KB', status: 'success' },
  ]);

  const stats = [
    { label: 'إجمالي التحويلات', value: '127', icon: TrendingUp, color: 'blue' },
    { label: 'الملفات المحفوظة', value: '43', icon: FileText, color: 'green' },
    { label: 'الاستخدام هذا الشهر', value: '2.3 GB', icon: Zap, color: 'purple' },
    { label: 'معدل النجاح', value: '98.5%', icon: BarChart3, color: 'emerald' },
  ];

  const savedFiles = [
    { id: 1, name: 'presentation_final.pdf', date: '2024-01-15', size: '5.2 MB' },
    { id: 2, name: 'report_2024.docx', date: '2024-01-14', size: '1.1 MB' },
    { id: 3, name: 'design_mockup.psd', date: '2024-01-13', size: '12.4 MB' },
  ];

  const getStatusColor = (status) => {
    return status === 'success' ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400';
  };

  const getStatusIcon = (status) => {
    return status === 'success' ? <ArrowUpRight size={16} /> : <ArrowDownLeft size={16} />;
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-slate-800 bg-slate-950/80 backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-600 flex items-center justify-center">
              <Zap size={24} className="text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">لوحة التحكم</h1>
              <p className="text-xs text-slate-400">مرحباً، أحمد محمد</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <button className="p-2 hover:bg-slate-800 rounded-lg transition">
              <Settings size={20} />
            </button>
            <button className="p-2 hover:bg-slate-800 rounded-lg transition">
              <LogOut size={20} />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {stats.map((stat, idx) => {
            const Icon = stat.icon;
            const colorMap = {
              blue: 'from-blue-600/20 to-blue-600/5',
              green: 'from-green-600/20 to-green-600/5',
              purple: 'from-purple-600/20 to-purple-600/5',
              emerald: 'from-emerald-600/20 to-emerald-600/5',
            };
            return (
              <div key={idx} className={`bg-gradient-to-br ${colorMap[stat.color]} border border-slate-800 rounded-xl p-6 hover:border-slate-700 transition`}>
                <div className="flex items-start justify-between mb-4">
                  <Icon size={24} className="text-blue-400" />
                </div>
                <p className="text-slate-400 text-sm mb-2">{stat.label}</p>
                <p className="text-3xl font-bold text-white">{stat.value}</p>
              </div>
            );
          })}
        </div>

        {/* Tabs */}
        <div className="flex gap-4 mb-6 border-b border-slate-800">
          {[
            { id: 'overview', label: 'نظرة عامة', icon: BarChart3 },
            { id: 'history', label: 'السجل التاريخي', icon: History },
            { id: 'files', label: 'الملفات المحفوظة', icon: FileText },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-3 font-medium transition border-b-2 ${
                  activeTab === tab.id ? 'border-blue-600 text-blue-400' : 'border-transparent text-slate-400 hover:text-slate-300'
                }`}
              >
                <Icon size={18} />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Tab Content */}
        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Quick Convert */}
            <div className="lg:col-span-1">
              <div className="bg-gradient-to-br from-blue-600/10 to-slate-900 border border-slate-800 rounded-xl p-6">
                <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                  <Plus size={20} className="text-blue-400" />
                  تحويل سريع
                </h3>
                <div className="space-y-3">
                  <input
                    type="file"
                    className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-sm text-slate-300 placeholder-slate-500 focus:outline-none focus:border-blue-600 transition"
                    placeholder="اختر ملف"
                  />
                  <select className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-sm text-slate-300 focus:outline-none focus:border-blue-600 transition">
                    <option>اختر صيغة الإخراج</option>
                    <option>PDF</option>
                    <option>Word</option>
                    <option>Excel</option>
                    <option>Image</option>
                  </select>
                  <button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-lg transition flex items-center justify-center gap-2">
                    <Zap size={18} />
                    تحويل الآن
                  </button>
                </div>
              </div>
            </div>

            {/* Recent Conversions */}
            <div className="lg:col-span-2">
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
                <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                  <History size={20} className="text-blue-400" />
                  آخر التحويلات
                </h3>
                <div className="space-y-3">
                  {conversions.slice(0, 3).map((conv) => (
                    <div key={conv.id} className="flex items-center justify-between p-4 bg-slate-800/50 rounded-lg hover:bg-slate-800 transition">
                      <div className="flex items-center gap-3 flex-1">
                        <div className={`p-2 rounded-lg ${getStatusColor(conv.status)}`}>
                          {getStatusIcon(conv.status)}
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium text-white">
                            {conv.from} → {conv.to}
                          </p>
                          <p className="text-xs text-slate-400">{conv.date}</p>
                        </div>
                        <p className="text-xs text-slate-400">{conv.size}</p>
                      </div>
                      <button className="p-2 hover:bg-slate-700 rounded-lg transition">
                        <Download size={16} className="text-slate-400" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'history' && (
          <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-800 border-b border-slate-700">
                  <tr>
                    <th className="px-6 py-4 text-right text-sm font-semibold text-slate-300">من</th>
                    <th className="px-6 py-4 text-right text-sm font-semibold text-slate-300">إلى</th>
                    <th className="px-6 py-4 text-right text-sm font-semibold text-slate-300">التاريخ</th>
                    <th className="px-6 py-4 text-right text-sm font-semibold text-slate-300">الحجم</th>
                    <th className="px-6 py-4 text-right text-sm font-semibold text-slate-300">الحالة</th>
                    <th className="px-6 py-4 text-right text-sm font-semibold text-slate-300">الإجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {conversions.map((conv) => (
                    <tr key={conv.id} className="hover:bg-slate-800/50 transition">
                      <td className="px-6 py-4 text-sm text-slate-300">{conv.from}</td>
                      <td className="px-6 py-4 text-sm text-slate-300">{conv.to}</td>
                      <td className="px-6 py-4 text-sm text-slate-400">{conv.date}</td>
                      <td className="px-6 py-4 text-sm text-slate-400">{conv.size}</td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(conv.status)}`}>
                          {getStatusIcon(conv.status)}
                          {conv.status === 'success' ? 'نجح' : 'فشل'}
                        </span>
                      </td>
                      <td className="px-6 py-4 flex items-center gap-2">
                        <button className="p-2 hover:bg-slate-700 rounded-lg transition">
                          <Download size={16} className="text-slate-400" />
                        </button>
                        <button className="p-2 hover:bg-slate-700 rounded-lg transition">
                          <Share2 size={16} className="text-slate-400" />
                        </button>
                        <button className="p-2 hover:bg-red-500/20 rounded-lg transition">
                          <Trash2 size={16} className="text-red-400" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'files' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {savedFiles.map((file) => (
              <div key={file.id} className="bg-slate-900 border border-slate-800 rounded-xl p-4 hover:border-slate-700 transition group">
                <div className="flex items-start justify-between mb-3">
                  <FileText size={24} className="text-blue-400" />
                  <button className="p-2 opacity-0 group-hover:opacity-100 hover:bg-slate-800 rounded-lg transition">
                    <Trash2 size={16} className="text-red-400" />
                  </button>
                </div>
                <p className="font-medium text-white text-sm mb-1 truncate">{file.name}</p>
                <p className="text-xs text-slate-400 mb-3">{file.size}</p>
                <div className="flex items-center justify-between pt-3 border-t border-slate-800">
                  <span className="text-xs text-slate-500">{file.date}</span>
                  <button className="p-1.5 hover:bg-slate-800 rounded-lg transition">
                    <Download size={14} className="text-blue-400" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}