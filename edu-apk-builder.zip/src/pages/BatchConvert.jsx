import React, { useEffect, useMemo, useState } from "react";

/**
 * Batch Converter - /batch-convert
 * Design: dark slate theme with blue accents, green success, red errors.
 * Tailwind CSS only. Lucide-like inline SVG icons.
 * Responsive, supports dark/light mode, Android-friendly layouts.
 * Note: Fonts are attributed via Tailwind utilities (font-sans for English, Arabic readable).
 */

// Inline Lucide-like icons
const IconUpload = (props) => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
    <polyline points="7 10 12 5 17 10" />
    <line x1="12" y1="5" x2="12" y2="15" />
  </svg>
);

const IconSettings = (props) => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...props}>
    <path d="M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z" />
    <path d="M19.4 15a1 1 0 0 0 .1-1.3l-1-1.7a1 1 0 0 0-.9-.4h-2.3a5.1 5.1 0 0 0-.7-1.7l1-1.96a1 1 0 0 0-.3-1.3l-1.9-1.8a1 1 0 0 0-1.2-.1l-2.2 1a5.1 5.1 0 0 0-1.6-.93l-.4-2.3A1 1 0 0 0 7 0h-2a1 1 0 0 0-.99.86l-.4 2.32A5.1 5.1 0 0 0 2.71 4l-1.9-1a1 1 0 0 0-1.2.16L0 4.77a1 1 0 0 0 .17 1.32l1.9 1.8a5.1 5.1 0 0 0 0 1.72l-1.9 1.8a1 1 0 0 0-.16 1.32l1.9 2.66a1 1 0 0 0 .99.43h2.3c.28 1.06 1 1.9 1.9 2.36l.3 1.92a1 1 0 0 0 1 0l2-1.2a1 1 0 0 0 .6-.92l.5-3.2c.64-.24 1.24-.57 1.8-.98l2.7.5a1 1 0 0 0 1-.6l1-2.2a1 1 0 0 0-.83-1.32l-2-.23c-.15-.96-.63-1.82-1.28-2.45l.9-2.1Z" />
  </svg>
);

const IconCheck = (props) => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" {...props}>
    <path d="M20 6L9 17l-5-5" />
  </svg>
);

const IconX = (props) => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" {...props}>
    <path d="M18 6L6 18" />
    <path d="M6 6l12 12" />
  </svg>
);

const IconTrash = (props) => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...props}>
    <polyline points="3 6 5 6 21 6" />
    <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
    <path d="M10 11v6" />
    <path d="M14 11v6" />
    <path d="M9 6V4h6v2" />
  </svg>
);

const IconFile = (props) => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...props}>
    <path d="M14 3H6a2 2 0 0 0-2 2v14l4-4h6a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2Z" />
    <path d="M14 3v6h6" />
  </svg>
);

const IconClock = (props) => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...props}>
    <circle cx="12" cy="12" r="9" />
    <path d="M12 7v5l3 3" />
  </svg>
);

export default function BatchConverterPage() {
  // Theme handling (dark/light)
  const [isDark, setIsDark] = useState(true);
  useEffect(() => {
    const root = document.documentElement;
    if (isDark) root.classList.add("dark");
    else root.classList.remove("dark");
  }, [isDark]);

  // Files
  const [files, setFiles] = useState([]);
  const [dragOver, setDragOver] = useState(false);

  // Options
  const [format, setFormat] = useState("PDF");
  const [resolution, setResolution] = useState(300);
  const [preserveMeta, setPreserveMeta] = useState(true);
  const [overwrite, setOverwrite] = useState(true);
  const [concurrency, setConcurrency] = useState(2);
  const [outputPattern, setOutputPattern] = useState("batch-{index}");

  // Conversion status
  const [progress, setProgress] = useState(0);
  const [isConverting, setIsConverting] = useState(false);
  const [statusMsg, setStatusMsg] = useState("");

  const totalSize = useMemo(
    () => files.reduce((acc, f) => acc + f.size, 0),
    [files]
  );
  const totalFiles = files.length;

  // Helpers
  const addFiles = (newFiles) => {
    const added = Array.from(newFiles).filter((f) => f.name);
    // Avoid duplicates by name + size
    const merged = [...files];
    added.forEach((f) => {
      if (!merged.find((mf) => mf.name === f.name && mf.size === f.size)) {
        merged.push({ file: f, id: `${f.name}-${f.size}-${f.lastModified}`, name: f.name, size: f.size, type: f.type });
      }
    });
    setFiles(merged);
  };

  const onDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer?.files?.length) {
      addFiles(e.dataTransfer.files);
    }
  };

  const onFileInputChange = (e) => {
    if (e.target.files?.length) {
      addFiles(e.target.files);
      // reset input for same-file selection
      e.target.value = "";
    }
  };

  const removeFile = (id) => {
    setFiles((curr) => curr.filter((f) => f.id !== id));
  };

  // Simulated conversion
  const startConversion = () => {
    if (files.length === 0) return;
    setIsConverting(true);
    setStatusMsg("Starting batch conversion...");
    setProgress(0);
    // Simple simulated progress per file
    const total = files.length;
    let completed = 0;
    const interval = setInterval(() => {
      // advance in steps
      completed += 1;
      const p = Math.min(100, Math.round((completed / total) * 100));
      setProgress(p);
      if (p >= 100) {
        clearInterval(interval);
        setIsConverting(false);
        setStatusMsg("Batch conversion completed successfully.");
      }
    }, 400);
  };

  // Prevent default drag behaviors
  useEffect(() => {
    const prevent = (e) => e.preventDefault();
    window.addEventListener("dragover", prevent);
    window.addEventListener("drop", prevent);
    return () => {
      window.removeEventListener("dragover", prevent);
      window.removeEventListener("drop", prevent);
    };
  }, []);

  // UI helpers
  const humanSize = (bytes) => {
    if (bytes < 1024) return `${bytes} B`;
    const units = ["KB", "MB", "GB"];
    let i = -1;
    let val = bytes;
    do {
      val = val / 1024;
      i++;
    } while (val >= 1024 && i < units.length - 1);
    return `${val.toFixed(1)} ${units[i]}`;
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans">
      <header className="border-b border-slate-800/50 bg-slate-900/60 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="inline-flex items-center justify-center w-9 h-9 rounded-full bg-blue-600 text-white font-semibold shadow-md">
              <IconUpload />
            </span>
            <div className="flex flex-col leading-tight">
              <span className="text-sm font-semibold tracking-wide uppercase">Batch Converter</span>
              <span className="text-xs text-slate-300">Path: /batch-convert</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsConverting(false)}
              className="px-3 py-2 rounded-md text-sm bg-blue-600 hover:bg-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-400"
              aria-label="Cancel conversion"
            >
              Cancel
            </button>
            <button
              onClick={() => setIsDark((d) => !d)}
              className="px-3 py-2 rounded-md text-sm bg-slate-800 hover:bg-slate-700 border border-slate-700"
              aria-label="Toggle theme"
            >
              {isDark ? "Light" : "Dark"} mode
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-4 sm:p-6">
        <section className="mb-6">
          <div className="rounded-xl bg-slate-800/60 border border-slate-700 p-6 shadow-md">
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div className="flex items-center gap-3">
                <span className="inline-flex items-center justify-center w-8 h-8 rounded-md bg-blue-600 text-white">
                  <IconSettings />
                </span>
                <div>
                  <h1 className="text-2xl font-semibold">Batch Conversion Studio</h1>
                  <p className="text-sm text-slate-300">
                    Convert multiple files in a single operation with unified options and settings.
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-1 text-xs rounded-full bg-blue-600 text-white">
                  Blue tone
                </span>
                <span className="px-2 py-1 text-xs rounded-full bg-green-500 text-white">
                  Ready
                </span>
              </div>
            </div>
          </div>
        </section>

        <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left: Upload & Files */}
          <div className="col-span-1">
            <div className="rounded-xl border border-slate-700 bg-slate-900/60 p-5 shadow-md">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2 text-sm font-medium">
                  <span className="inline-flex items-center justify-center w-6 h-6 rounded-md bg-slate-700 text-slate-100">
                    <IconUpload />
                  </span>
                  <span>Files</span>
                </div>
                <span className="text-xs text-slate-400">
                  {totalFiles} file{totalFiles !== 1 ? "s" : ""} • {humanSize(totalSize)}
                </span>
              </div>

              <div
                className={`border-2 border-dashed rounded-lg p-6 mb-4 text-center cursor-pointer ${
                  dragOver ? "border-blue-400 border-2" : "border-slate-700"
                }`}
                onDragOver={(e) => {
                  e.preventDefault();
                  setDragOver(true);
                }}
                onDragLeave={() => setDragOver(false)}
                onDrop={onDrop}
              >
                <div className="mb-2 text-blue-300">
                  <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-slate-800">
                    <IconFile />
                  </span>
                </div>
                <div className="text-lg font-medium mb-1">Drop files here or click to browse</div>
                <div className="text-sm text-slate-400 mb-2">Supports multiple files at once</div>
                <input
                  id="hidden-file-input"
                  type="file"
                  multiple
                  className="hidden"
                  onChange={onFileInputChange}
                />
                <button
                  onClick={() => document.getElementById("hidden-file-input").click()}
                  className="mt-2 inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-md shadow hover:bg-blue-500 focus:outline-none"
                >
                  Browse Files
                </button>
              </div>

              <div className="max-h-60 overflow-y-auto pr-2" aria-label="Selected files list">
                {files.length === 0 ? (
                  <div className="text-sm text-slate-400 italic py-2">No files selected yet.</div>
                ) : (
                  <ul className="space-y-2">
                    {files.map((f) => (
                      <li
                        key={f.id}
                        className="flex items-center justify-between gap-2 rounded-md p-2 bg-slate-850/60 hover:bg-slate-800"
                      >
                        <div className="flex items-center gap-2">
                          <span className="text-slate-200">
                            <IconFile />
                          </span>
                          <span className="text-sm truncate" title={f.name}>
                            {f.name}
                          </span>
                          <span className="text-xs text-slate-400 ml-2">{humanSize(f.size)}</span>
                        </div>
                        <button
                          onClick={() => removeFile(f.id)}
                          className="p-1 rounded hover:bg-slate-700"
                          aria-label={`Remove ${f.name}`}
                          title="Remove"
                        >
                          <IconTrash />
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          </div>

          {/* Right: Options & Summary */}
          <div className="col-span-1">
            <div className="rounded-xl border border-slate-700 bg-slate-900/60 p-5 shadow-md">
              <div className="flex items-center justify-between mb-3">
                <div className="text-sm font-medium">Options</div>
                <span className="text-xs text-slate-400">
                  <IconClock /> Config
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-slate-300 mb-1">Output format</label>
                  <select
                    value={format}
                    onChange={(e) => setFormat(e.target.value)}
                    className="w-full rounded-md bg-slate-800 border border-slate-700 px-3 py-2 text-sm text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option>PDF</option>
                    <option>DOCX</option>
                    <option>PNG</option>
                    <option>ZIP</option>
                    <option>TXT</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs text-slate-300 mb-1">Resolution (DPI)</label>
                  <input
                    type="number"
                    min={72}
                    max={600}
                    value={resolution}
                    onChange={(e) => setResolution(Number(e.target.value))}
                    className="w-full rounded-md bg-slate-800 border border-slate-700 px-3 py-2 text-sm text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div className="col-span-2 flex items-center gap-2">
                  <input
                    id="preserve-meta"
                    type="checkbox"
                    checked={preserveMeta}
                    onChange={(e) => setPreserveMeta(e.target.checked)}
                    className="w-4 h-4 accent-blue-500"
                  />
                  <label htmlFor="preserve-meta" className="text-sm text-slate-300">
                    Preserve metadata
                  </label>
                  <span className="ml-2 px-2 py-1 text-xs rounded bg-slate-800 border border-slate-700 text-slate-300">
                    {preserveMeta ? "On" : "Off"}
                  </span>
                </div>

                <div className="col-span-2 flex items-center gap-2">
                  <input
                    id="overwrite"
                    type="checkbox"
                    checked={overwrite}
                    onChange={(e) => setOverwrite(e.target.checked)}
                    className="w-4 h-4 accent-blue-500"
                  />
                  <label htmlFor="overwrite" className="text-sm text-slate-300">
                    Overwrite existing files
                  </label>
                  <span className="ml-2 px-2 py-1 text-xs rounded bg-slate-800 border border-slate-700 text-slate-300">
                    {overwrite ? "Allowed" : "Prevented"}
                  </span>
                </div>

                <div className="col-span-2">
                  <label className="block text-xs text-slate-300 mb-1">Output name pattern</label>
                  <input
                    type="text"
                    value={outputPattern}
                    onChange={(e) => setOutputPattern(e.target.value)}
                    className="w-full rounded-md bg-slate-800 border border-slate-700 px-3 py-2 text-sm text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="batch-{index}"
                  />
                </div>

                <div className="col-span-2 pt-2">
                  <label className="block text-xs text-slate-300 mb-1">Concurrency</label>
                  <input
                    type="range"
                    min={1}
                    max={8}
                    value={concurrency}
                    onChange={(e) => setConcurrency(Number(e.target.value))}
                    className="w-full"
                  />
                  <div className="text-xs text-slate-400 text-right">{concurrency} parallel tasks</div>
                </div>
              </div>

              <div className="border-t border-slate-700 mt-4 pt-4 grid grid-cols-1 gap-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-300">Total files</span>
                  <span className="text-sm font-medium">{totalFiles}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-300">Total size</span>
                  <span className="text-sm font-medium">{humanSize(totalSize)}</span>
                </div>
              </div>
            </div>

            <div className="mt-4 rounded-xl border border-slate-700 bg-slate-900/60 p-4 shadow-md">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Batch status</span>
                {isConverting ? (
                  <span className="text-xs text-blue-400 font-medium">In progress</span>
                ) : (
                  <span className="text-xs text-slate-300">Idle</span>
                )}
              </div>

              <div className="h-2 rounded-full bg-slate-800 overflow-hidden" aria-label="Progress bar">
                <div
                  className="h-full bg-blue-600"
                  style={{ width: `${progress}%`, transition: "width 150ms ease-in" }}
                />
              </div>

              <div className="mt-2 flex items-center justify-between text-xs text-slate-400">
                <span>{progress}%</span>
                <span className="flex items-center gap-1">
                  {progress < 100 ? (
                    <>
                      <span>Estimated time: </span>
                      <span className="italic">≈{Math.max(1, Math.round((100 - progress) / 10))}s</span>
                    </>
                  ) : (
                    <span>Completed</span>
                  )}
                </span>
              </div>

              <div className="mt-3 flex gap-2">
                <button
                  onClick={startConversion}
                  disabled={files.length === 0 || isConverting}
                  className={`w-full px-4 py-2 rounded-md text-sm font-medium shadow
                    ${files.length === 0 || isConverting ? "bg-slate-700 text-slate-400 cursor-not-allowed" : "bg-blue-600 hover:bg-blue-500 text-white"}
                  `}
                >
                  Start Batch Convert
                </button>
                <button
                  onClick={() => {
                    setFiles([]);
                    setProgress(0);
                    setStatusMsg("Cleared file list.");
                  }}
                  className="w-full px-4 py-2 rounded-md text-sm font-medium bg-slate-800 hover:bg-slate-700"
                >
                  Clear List
                </button>
              </div>

              {statusMsg && (
                <div className="mt-3 p-2 rounded-md bg-slate-800 text-sm text-slate-100 border border-slate-700" role="status" aria-live="polite">
                  {statusMsg}
                </div>
              )}
            </div>
          </div>
        </section>
      </main>

      <footer className="mt-10 border-t border-slate-800/50 py-6 text-sm text-slate-400">
        <div className="max-w-7xl mx-auto px-4 flex items-center justify-between">
          <span>© 2026 Batch Converter Studio</span>
          <span>Designed with Material-inspired principles • Dark/Light ready</span>
        </div>
      </footer>
    </div>
  );
}