import React, { useEffect, useMemo, useRef, useState } from "react";

/* Lightweight Lucide-inspired inline icons (no external assets) */
const IconSun = (props) => (
  <svg viewBox="0 0 24 24" width={20} height={20} fill="none" stroke="currentColor" strokeWidth="2" {...props}>
    <circle cx="12" cy="12" r="4" />
    <path d="M12 2v2m0 16v2M4.93 4.93l1.41 1.41m12.73 12.73 1.41 1.41M2 12h2m16 0h2M4.93 19.07l1.41-1.41m12.73-12.73-1.41-1.41" />
  </svg>
);

const IconMoon = (props) => (
  <svg viewBox="0 0 24 24" width={20} height={20} fill="none" stroke="currentColor" strokeWidth="2" {...props}>
    <path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z" />
  </svg>
);

const IconUpload = (props) => (
  <svg viewBox="0 0 24 24" width={20} height={20} fill="none" stroke="currentColor" strokeWidth="2" {...props}>
    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
    <polyline points="17 8 12 3 7 8" />
    <line x1="12" y1="3" x2="12" y2="15" />
  </svg>
);

const IconFile = (props) => (
  <svg viewBox="0 0 24 24" width={20} height={20} fill="none" stroke="currentColor" strokeWidth="2" {...props}>
    <path d="M14 2H6a2 2 0 0 0-2 2v16l4-4h6a2 2 0 0 0 2-2V2z" />
    <path d="M14 2v6h6" />
  </svg>
);

const IconChevronDown = (props) => (
  <svg viewBox="0 0 24 24" width={18} height={18} fill="none" stroke="currentColor" strokeWidth="2" {...props}>
    <polyline points="6 9 12 15 18 9" />
  </svg>
);

const IconCheck = (props) => (
  <svg viewBox="0 0 24 24" width={18} height={18} fill="none" stroke="currentColor" strokeWidth="3" {...props}>
    <path d="M20 6L9 17l-5-5" />
  </svg>
);

const IconX = (props) => (
  <svg viewBox="0 0 24 24" width={18} height={18} fill="none" stroke="currentColor" strokeWidth="3" {...props}>
    <path d="M18 6L6 18M6 6l12 12" />
  </svg>
);

const IconSettings = (props) => (
  <svg viewBox="0 0 24 24" width={18} height={18} fill="none" stroke="currentColor" strokeWidth="2" {...props}>
    <path d="M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z" />
    <path d="M19.4 15a1.65 1.65 0 0 0 .33.82l1.54 2.68-1.99 1.99-2.68-1.54a1.65 1.65 0 0 0-.82.33l-1 1.73-2.12-1.23 1-1.73a1.65 1.65 0 0 0-.33-.82l-1.54-2.68L4.6 15.7l1.54 2.68a1.65 1.65 0 0 0-.33.82l-1 1.73 2.12 1.23 1-1.73a1.65 1.65 0 0 0-.33-.82l.92-.92" />
  </svg>
);

export default function Converter() {
  const [darkMode, setDarkMode] = useState(true);
  const [dragOver, setDragOver] = useState(false);
  const [file, setFile] = useState(null);
  const [sourceFormat, setSourceFormat] = useState("CSV");
  const [targetFormat, setTargetFormat] = useState("JSON");
  const [preview, setPreview] = useState("");
  const [advancedOpen, setAdvancedOpen] = useState(true);
  const [delimiter, setDelimiter] = useState(",");
  const [quoteChar, setQuoteChar] = useState('"');
  const [hasHeader, setHasHeader] = useState(true);
  const [skipLines, setSkipLines] = useState(0);
  const [isConverting, setIsConverting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [resultMessage, setResultMessage] = useState("");
  const fileInputRef = useRef(null);

  useEffect(() => {
    // initialize theme
    // apply dark class on root element for Tailwind dark mode
    if (typeof window !== "undefined") {
      document.documentElement.classList.toggle("dark", darkMode);
    }
  }, [darkMode]);

  // Generate a mock preview if no file
  useEffect(() => {
    if (file && file.name) {
      readPreviewFile(file);
    } else {
      setPreview("مثال: هذا عرض للمعاينة قبل التحويل. حدد ملفاً ليتم عرض جزء من محتواه هنا.");
    }
  }, [file]);

  function readPreviewFile(f) {
    const reader = new FileReader();
    reader.onload = () => {
      const text = String(reader.result);
      const snippet = text.length > 600 ? text.substring(0, 600) + "..." : text;
      setPreview(snippet);
    };
    reader.onerror = () => {
      setPreview("لا يمكن عرض معاينة الملف حالياً.");
    };
    // Try to read as text; if binary, catch error and show a friendly message
    reader.readAsText(f);
  }

  function onFilesSelected(e) {
    const f = e.target.files?.[0];
    if (f) {
      setFile(f);
    }
  }

  function triggerFileDialog() {
    fileInputRef.current?.click();
  }

  function handleDrop(e) {
    e.preventDefault();
    setDragOver(false);
    const f = e.dataTransfer?.files?.[0];
    if (f) {
      setFile(f);
    }
  }

  function handleDragOver(e) {
    e.preventDefault();
    setDragOver(true);
  }

  function handleDragLeave() {
    setDragOver(false);
  }

  function resetAll() {
    setFile(null);
    setPreview("");
    setSourceFormat("CSV");
    setTargetFormat("JSON");
    setDelimiter(",");
    setQuoteChar('"');
    setHasHeader(true);
    setSkipLines(0);
    setAdvancedOpen(true);
    setResultMessage("");
    setProgress(0);
  }

  function startConversion() {
    if (!file) return;
    if (!sourceFormat || !targetFormat) return;
    setIsConverting(true);
    setProgress(0);
    setResultMessage("");
    // simulate progress
    const total = 100;
    let p = 0;
    const interval = setInterval(() => {
      p += 8 + Math.round(Math.random() * 6);
      if (p >= total) {
        p = total;
        clearInterval(interval);
        setIsConverting(false);
        setResultMessage("Conversion complete. الدالة تعمل بنجاح.");
      }
      setProgress(p);
    }, 180);
  }

  const canConvert = useMemo(() => {
    return !!file && !!sourceFormat && !!targetFormat && !isConverting;
  }, [file, sourceFormat, targetFormat, isConverting]);

  // Simple responsive layout pieces
  return (
    <div className={`min-h-screen relative ${darkMode ? "" : ""}`} style={{ backgroundColor: "#0f172a" }}>
      {/* Top navigation / header */}
      <header className="w-full sticky top-0 z-10 bg-slate-900/70 backdrop-blur-md border-b border-slate-700/40">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="inline-flex items-center justify-center h-9 w-9 rounded-full bg-blue-600 text-white shadow-md">
              <IconUpload />
            </span>
            <h1 className="text-white text-xl sm:text-2xl font-semibold tracking-wide">
              محول الملفات
              <span className="text-slate-300 text-sm hidden md:inline">مسار: /converter</span>
            </h1>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setDarkMode((d) => !d)}
              aria-label="Toggle theme"
              className="text-slate-100 hover:text-white p-2 rounded-md bg-slate-700/60 hover:bg-slate-600/60 transition"
              title="Toggle dark/light"
            >
              {darkMode ? <IconSun /> : <IconMoon />}
            </button>
            <button
              onClick={resetAll}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white px-3 py-2 rounded-md shadow"
              title="إعادة تعيين"
            >
              <IconX />
              <span className="hidden sm:inline">إعادة تعيين</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left column: Upload + Formats + Advanced */}
          <div className="bg-slate-900 dark:bg-white/90 rounded-xl shadow-xl border border-slate-700/40 p-6 transition-shadow duration-300 hover:shadow-2xl flex flex-col gap-5" style={{ backdropFilter: "saturate(1.2) blur(0.2px)" }}>
            {/* Upload Card */}
            <div className="rounded-xl border border-slate-700/40 p-4 flex flex-col md:flex-row items-start md:items-center gap-4 bg-slate-900/60">
              <div className="flex-shrink-0 p-1 bg-blue-600 rounded-md">
                <IconFile />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h2 className="text-white text-lg font-semibold">رفع ملف واحد / Upload a single file</h2>
                  <span className="text-slate-300 text-sm">{file ? file.name : "لم يتم اختيار ملف"}</span>
                </div>
                <p className="text-slate-300 text-sm mt-1">
                  حدد ملفاً ليتم تحويله من صيغة المصدر إلى الصيغة الهدف. يمكنك سحب الملف هنا أو الضغط لتحديد ملف من جهازك.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={triggerFileDialog}
                  className="px-3 py-2 bg-green-500 text-white rounded-md shadow hover:bg-green-600"
                >
                  اختيار ملف
                </button>
                <button
                  onClick={() => setFile(null)}
                  className="px-3 py-2 bg-red-500 text-white rounded-md shadow hover:bg-red-600"
                  disabled={!file}
                  title="إزالة الملف المحدد"
                >
                  مسح
                </button>
              </div>
              <input
                ref={fileInputRef}
                type="file"
                className="hidden"
                onChange={onFilesSelected}
              />
            </div>

            {/* Dropzone */}
            <div
              className={`rounded-xl border-2 border-dashed border-blue-600/60 p-6 flex flex-col items-center justify-center text-center ${dragOver ? "bg-blue-600/10" : "bg-slate-900"} transition-all`}
              onDrop={handleDrop}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onClick={triggerFileDialog}
              role="button"
              aria-label="Drop file here or click to upload"
            >
              <div className="text-blue-300 mb-2">
                <IconUpload />
              </div>
              <p className="text-slate-200 text-sm md:text-base">
                اسحب الملف هنا أو انقر لاختيار ملف واحد فقط. أنواع الملفات المدعومة: كافة الأنواع.
              </p>
              <span className="mt-2 text-xs text-slate-400">Tip: يدعم تحويل أساسي من CSV/JSON/XML وغيرها بشكل افتراضي.</span>
            </div>

            {/* Formats Row */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-slate-900 rounded-xl p-4 border border-slate-700/40">
                <label className="block text-slate-200 text-sm mb-2">الصيغة المصدر Source format</label>
                <select
                  value={sourceFormat}
                  onChange={(e) => setSourceFormat(e.target.value)}
                  className="w-full bg-slate-800 text-white rounded-md border border-slate-700 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option>CSV</option>
                  <option>JSON</option>
                  <option>XML</option>
                  <option>TXT</option>
                </select>
              </div>
              <div className="bg-slate-900 rounded-xl p-4 border border-slate-700/40">
                <label className="block text-slate-200 text-sm mb-2">الصيغة الهدف Target format</label>
                <select
                  value={targetFormat}
                  onChange={(e) => setTargetFormat(e.target.value)}
                  className="w-full bg-slate-800 text-white rounded-md border border-slate-700 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option>JSON</option>
                  <option>CSV</option>
                  <option>XML</option>
                  <option>TXT</option>
                </select>
              </div>
            </div>

            {/* Preview / Sample Display */}
            <div className="bg-slate-900 rounded-xl p-4 border border-slate-700/40">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <IconFile />
                  <span className="text-white font-semibold">معاينة المعطيات / Preview</span>
                </div>
                <span className="text-xs text-slate-400">{file ? file.name : "بدون ملف"}</span>
              </div>
              <div className="h-40 md:h-48 w-full rounded-md bg-slate-800 text-slate-100 overflow-auto p-3 text-xs md:text-sm">
                {preview || "لا توجد معاينة متاحة حتى الآن."}
              </div>
            </div>

            {/* Advanced Options Toggle */}
            <div className="flex items-center justify-between pt-2">
              <button
                onClick={() => setAdvancedOpen((s) => !s)}
                className="flex items-center gap-2 text-blue-400 hover:text-blue-300"
              >
                <IconChevronDown />
                خيارات متقدمة / Advanced options
              </button>
              <span className="text-slate-400 text-sm"> حالة المطابقة: {file ? "جاهز" : "إضافة ملف مطلوب"} </span>
            </div>

            {/* Advanced Options Panel */}
            {advancedOpen && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-1">
                <div className="bg-slate-900 rounded-xl p-4 border border-slate-700/40">
                  <label className="block text-slate-200 text-sm mb-2">Delimiter (CSV)</label>
                  <input
                    value={delimiter}
                    onChange={(e) => setDelimiter(e.target.value)}
                    className="w-full bg-slate-800 text-white rounded-md border border-slate-700 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder=","
                  />
                </div>
                <div className="bg-slate-900 rounded-xl p-4 border border-slate-700/40">
                  <label className="block text-slate-200 text-sm mb-2">Quote character</label>
                  <input
                    value={quoteChar}
                    onChange={(e) => setQuoteChar(e.target.value)}
                    className="w-full bg-slate-800 text-white rounded-md border border-slate-700 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder='"'
                  />
                </div>
                <div className="bg-slate-900 rounded-xl p-4 border border-slate-700/40 flex items-center justify-between">
                  <span className="text-slate-200 text-sm">Header row</span>
                  <button
                    onClick={() => setHasHeader((v) => !v)}
                    className={`h-6 w-12 rounded-full ${hasHeader ? "bg-green-500" : "bg-slate-700"}`}
                    aria-label="Toggle header"
                  >
                    <span className={`block w-6 h-6 bg-white rounded-full transform ${hasHeader ? "translate-x-6" : "translate-x-0"} transition`}></span>
                  </button>
                </div>
                <div className="bg-slate-900 rounded-xl p-4 border border-slate-700/40">
                  <label className="block text-slate-200 text-sm mb-2">Skip first N lines</label>
                  <input
                    type="number"
                    min={0}
                    value={skipLines}
                    onChange={(e) => setSkipLines(Number(e.target.value))}
                    className="w-full bg-slate-800 text-white rounded-md border border-slate-700 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Right column: Status & Actions */}
          <div className="flex flex-col gap-6">
            <div className="bg-slate-900 dark:bg-white/90 rounded-xl shadow-xl border border-slate-700/40 p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-blue-400">
                    <IconSettings />
                  </span>
                  <h3 className="text-white text-lg font-semibold">لوحة التحكّم / Control Panel</h3>
                </div>
                <span className="text-xs text-slate-300">
                  تحويل من {sourceFormat} → {targetFormat}
                </span>
              </div>
              <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-slate-900 rounded-lg p-3 border border-slate-700">
                  <div className="text-xs text-slate-300">Current file</div>
                  <div className="text-sm font-medium text-white truncate">
                    {file ? file.name : "لا يوجد ملف محدد"}
                  </div>
                </div>
                <div className="bg-slate-900 rounded-lg p-3 border border-slate-700">
                  <div className="text-xs text-slate-300">Progress</div>
                  <div className="h-2 bg-slate-700 rounded-full mt-1 overflow-hidden">
                    <div
                      className="h-full bg-blue-500"
                      style={{ width: `${progress}%`, transition: "width 0.2s ease" }}
                    />
                  </div>
                  <div className="text-xs text-slate-300 mt-1">{progress}%</div>
                </div>
              </div>
              <div className="mt-4 flex flex-col gap-3">
                <button
                  onClick={startConversion}
                  disabled={!canConvert}
                  className={`w-full py-3 rounded-md text-white font-semibold shadow ${canConvert ? "bg-blue-600 hover:bg-blue-500" : "bg-slate-700/60 cursor-not-allowed"}`}
                >
                  {isConverting ? "جارٍ التحويل..." : "ابدأ التحويل / Start Conversion"}
                </button>
                <button
                  onClick={() => setResultMessage("")}
                  className="w-full py-2 rounded-md bg-slate-800 text-slate-100 hover:bg-slate-700"
                >
                  إخفاء النتائج
                </button>
              </div>
              {resultMessage && (
                <div className="mt-4 p-3 rounded-md bg-green-500/20 border border-green-500 text-green-100">
                  <span className="inline-flex items-center gap-2">
                    <IconCheck />
                    {resultMessage}
                  </span>
                </div>
              )}
            </div>

            {/* Footer / Informational Note */}
            <div className="rounded-xl bg-slate-950 dark:bg-white/90 p-4 border border-slate-700/40">
              <div className="flex items-center gap-2 text-slate-200">
                <span className="text-sm">ملاحظات</span>
              </div>
              <p className="text-xs text-slate-300 mt-1">
                هذه صفحة نموذجية تعكس مبادئ التصميم الحديثة باستخدام لوحة ألوان داكنة مع لمسات أزرق/أخضر/أحمر. دعم الوضع الليلي والفاتح متاح بشكل كامل.
              </p>
            </div>
          </div>
        </section>
      </main>

      {/* Bottom spacer to ensure comfortable scrolling on small screens */}
      <div className="h-12" aria-hidden="true" />
    </div>
  );
}