export default function SettingsPage() {
  const [language, setLanguage] = React.useState('ar');
  const [notifications, setNotifications] = React.useState({
    email: true,
    push: true,
    sms: false,
  });
  const [theme, setTheme] = React.useState('dark');
  const [activeTab, setActiveTab] = React.useState('general');

  const isArabic = language === 'ar';
  const dir = isArabic ? 'rtl' : 'ltr';

  const translations = {
    ar: {
      settings: 'الإعدادات',
      general: 'عام',
      notifications: 'الإشعارات',
      account: 'الحساب',
      privacy: 'الخصوصية',
      language: 'اللغة',
      selectLanguage: 'اختر اللغة المفضلة',
      arabic: 'العربية',
      english: 'English',
      theme: 'المظهر',
      darkMode: 'الوضع الليلي',
      lightMode: 'الوضع الفاتح',
      emailNotifications: 'إشعارات البريد الإلكتروني',
      pushNotifications: 'إشعارات فورية',
      smsNotifications: 'إشعارات الرسائل القصيرة',
      accountSettings: 'إعدادات الحساب',
      email: 'البريد الإلكتروني',
      username: 'اسم المستخدم',
      twoFactor: 'المصادقة الثنائية',
      enable: 'تفعيل',
      disable: 'تعطيل',
      changePassword: 'تغيير كلمة المرور',
      downloadData: 'تحميل بياناتي',
      deleteAccount: 'حذف الحساب',
      privacySettings: 'إعدادات الخصوصية',
      profileVisibility: 'ظهور الملف الشخصي',
      public: 'عام',
      private: 'خاص',
      save: 'حفظ التغييرات',
      saved: 'تم الحفظ بنجاح',
    },
    en: {
      settings: 'Settings',
      general: 'General',
      notifications: 'Notifications',
      account: 'Account',
      privacy: 'Privacy',
      language: 'Language',
      selectLanguage: 'Select your preferred language',
      arabic: 'العربية',
      english: 'English',
      theme: 'Theme',
      darkMode: 'Dark Mode',
      lightMode: 'Light Mode',
      emailNotifications: 'Email Notifications',
      pushNotifications: 'Push Notifications',
      smsNotifications: 'SMS Notifications',
      accountSettings: 'Account Settings',
      email: 'Email',
      username: 'Username',
      twoFactor: 'Two-Factor Authentication',
      enable: 'Enable',
      disable: 'Disable',
      changePassword: 'Change Password',
      downloadData: 'Download My Data',
      deleteAccount: 'Delete Account',
      privacySettings: 'Privacy Settings',
      profileVisibility: 'Profile Visibility',
      public: 'Public',
      private: 'Private',
      save: 'Save Changes',
      saved: 'Saved Successfully',
    },
  };

  const t = translations[language];

  const TabButton = ({ id, label, icon: Icon }) => (
    <button
      onClick={() => setActiveTab(id)}
      className={`flex items-center gap-2 px-4 py-3 rounded-lg transition-all duration-300 ${
        activeTab === id
          ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
          : 'text-gray-400 hover:text-white hover:bg-slate-800'
      }`}
    >
      <Icon size={20} />
      <span className="hidden sm:inline font-medium">{label}</span>
    </button>
  );

  const SettingItem = ({ label, children, icon: Icon }) => (
    <div className="flex items-start gap-4 p-4 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 transition-colors">
      <div className="mt-1 p-2 rounded-lg bg-blue-600/10">
        <Icon size={20} className="text-blue-600" />
      </div>
      <div className="flex-1 min-w-0">
        <h3 className="font-semibold text-white mb-2">{label}</h3>
        {children}
      </div>
    </div>
  );

  const Toggle = ({ checked, onChange }) => (
    <button
      onClick={() => onChange(!checked)}
      className={`relative inline-flex h-7 w-12 items-center rounded-full transition-colors ${
        checked ? 'bg-green-500' : 'bg-slate-700'
      }`}
    >
      <span
        className={`inline-block h-5 w-5 transform rounded-full bg-white transition-transform ${
          checked ? 'translate-x-6' : (isArabic ? '-translate-x-1' : 'translate-x-1')
        }`}
      />
    </button>
  );

  return (
    <div
      dir={dir}
      className={`min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-white p-4 sm:p-6 ${
        isArabic ? 'font-[Tajawal]' : 'font-[Inter]'
      }`}
    >
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl sm:text-4xl font-bold mb-2 flex items-center gap-3">
          <div className="p-3 rounded-lg bg-blue-600/20 border border-blue-600/30">
            <svg
              className="w-8 h-8 text-blue-600"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"
              />
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
              />
            </svg>
          </div>
          {t.settings}
        </h1>
        <p className="text-gray-400 text-sm sm:text-base">
          {isArabic ? 'أدر تفضيلاتك وإعدادات حسابك' : 'Manage your preferences and account settings'}
        </p>
      </div>

      {/* Tabs */}
      <div className="mb-8 flex flex-wrap gap-2 sm:gap-3 p-3 rounded-xl bg-slate-900/50 border border-slate-800">
        <TabButton id="general" label={t.general} icon={SettingsIcon} />
        <TabButton id="notifications" label={t.notifications} icon={BellIcon} />
        <TabButton id="account" label={t.account} icon={UserIcon} />
        <TabButton id="privacy" label={t.privacy} icon={LockIcon} />
      </div>

      {/* Content */}
      <div className="max-w-4xl">
        {/* General Tab */}
        {activeTab === 'general' && (
          <div className="space-y-4 animate-fade-in">
            <SettingItem label={t.language} icon={GlobeIcon}>
              <div className="flex gap-3 flex-wrap">
                {[
                  { code: 'ar', label: t.arabic },
                  { code: 'en', label: t.english },
                ].map((lang) => (
                  <button
                    key={lang.code}
                    onClick={() => setLanguage(lang.code)}
                    className={`px-4 py-2 rounded-lg font-medium transition-all ${
                      language === lang.code
                        ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
                        : 'bg-slate-800 text-gray-300 hover:bg-slate-700'
                    }`}
                  >
                    {lang.label}
                  </button>
                ))}
              </div>
            </SettingItem>

            <SettingItem label={t.theme} icon={SunIcon}>
              <div className="flex gap-3 flex-wrap">
                {[
                  { id: 'dark', label: t.darkMode },
                  { id: 'light', label: t.lightMode },
                ].map((mode) => (
                  <button
                    key={mode.id}
                    onClick={() => setTheme(mode.id)}
                    className={`px-4 py-2 rounded-lg font-medium transition-all ${
                      theme === mode.id
                        ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
                        : 'bg-slate-800 text-gray-300 hover:bg-slate-700'
                    }`}
                  >
                    {mode.label}
                  </button>
                ))}
              </div>
            </SettingItem>
          </div>
        )}

        {/* Notifications Tab */}
        {activeTab === 'notifications' && (
          <div className="space-y-4 animate-fade-in">
            {[
              { key: 'email', label: t.emailNotifications, icon: MailIcon },
              { key: 'push', label: t.pushNotifications, icon: BellIcon },
              { key: 'sms', label: t.smsNotifications, icon: PhoneIcon },
            ].map((notif) => (
              <SettingItem key={notif.key} label={notif.label} icon={notif.icon}>
                <div className="flex items-center justify-between">
                  <span className="text-gray-400 text-sm">
                    {isArabic
                      ? 'تفعيل هذه الإشعارات'
                      : 'Enable these notifications'}
                  </span>
                  <Toggle
                    checked={notifications[notif.key]}
                    onChange={(val) =>
                      setNotifications({ ...notifications, [notif.key]: val })
                    }
                  />
                </div>
              </SettingItem>
            ))}
          </div>
        )}

        {/* Account Tab */}
        {activeTab === 'account' && (
          <div className="space-y-4 animate-fade-in">
            <SettingItem label={t.accountSettings} icon={UserIcon}>
              <div className="space-y-3">
                <div>
                  <label className="block text-sm text-gray-400 mb-2">
                    {t.email}
                  </label>
                  <input
                    type="email"
                    placeholder="user@example.com"
                    className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white placeholder-gray-500 focus:outline-none focus:border-blue-600 transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-2">
                    {t.username}
                  </label>
                  <input
                    type="text"
                    placeholder="username"
                    className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white placeholder-gray-500 focus:outline-none focus:border-blue-600 transition-colors"
                  />
                </div>
              </div>
            </SettingItem>

            <SettingItem label={t.twoFactor} icon={LockIcon}>
              <div className="flex items-center justify-between">
                <span className="text-gray-400 text-sm">
                  {isArabic
                    ? 'تحسين أمان حسابك'
                    : 'Enhance your account security'}
                </span>
                <button className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-medium transition-colors">
                  {t.enable}
                </button>
              </div>
            </SettingItem>

            <SettingItem label={t.changePassword} icon={KeyIcon}>
              <button className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-medium transition-colors">
                {t.changePassword}
              </button>
            </SettingItem>

            <div className="flex gap-3 pt-4">
              <button className="flex-1 px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-medium transition-colors">
                {t.downloadData}
              </button>
              <button className="flex-1 px-4 py-2 rounded-lg bg-red-600/10 hover:bg-red-600/20 text-red-500 font-medium transition-colors border border-red-600/30">
                {t.deleteAccount}
              </button>
            </div>
          </div>
        )}

        {/* Privacy Tab */}
        {activeTab === 'privacy' && (
          <div className="space-y-4 animate-fade-in">
            <SettingItem label={t.privacySettings} icon={ShieldIcon}>
              <div className="space-y-3">
                <div>
                  <label className="block text-sm text-gray-400 mb-3">
                    {t.profileVisibility}
                  </label>
                  <div className="flex gap-3">
                    {[
                      { id: 'public', label: t.public },
                      { id: 'private', label: t.private },
                    ].map((option) => (
                      <button
                        key={option.id}
                        className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-medium transition-colors border border-slate-700"
                      >
                        {option.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </SettingItem>
          </div>
        )}
      </div>

      {/* Save Button */}
      <div className="mt-8 flex justify-end gap-3">
        <button className="px-6 py-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-medium transition-colors">
          {isArabic ? 'إلغاء' : 'Cancel'}
        </button>
        <button className="px-6 py-3 rounded-lg bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-medium shadow-lg shadow-blue-600/30 transition-all">
          {t.save}
        </button>
      </div>

      <style jsx>{`
        @keyframes fade-in {
          from {
            opacity: 0;
            transform: translateY(10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .animate-fade-in {
          animation: fade-in 0.3s ease-out;
        }
      `}</style>
    </div>
  );
}

function SettingsIcon(props) {
  return (
    <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"
      />
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
      />
    </svg>
  );
}

function BellIcon(props) {
  return (
    <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"
      />
    </svg>
  );
}

function UserIcon(props) {
  return (
    <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
      />
    </svg>
  );
}

function LockIcon(props) {
  return (
    <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
      />
    </svg>
  );
}

function GlobeIcon(props) {
  return (
    <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20H7m6-4h6a2 2 0 002-2v-2.5a2.5 2.5 0 00-5 0v2.5a2 2 0 002 2z"
      />
    </svg>
  );
}

function SunIcon(props) {
  return (
    <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M12 3v1m0 16v1m9-9h-1m-16 0H1m15.364 1.636l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"
      />
    </svg>
  );
}

function MailIcon(props) {
  return (
    <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
      />
    </svg>
  );
}

function PhoneIcon(props) {
  return (
    <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z"
      />
    </svg>
  );
}

function KeyIcon(props) {
  return (
    <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"
      />
    </svg>
  );
}

function ShieldIcon(props) {
  return (
    <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
      />
    </svg>
  );
}