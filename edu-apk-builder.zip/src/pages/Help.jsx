import React, { useState } from 'react';
import {
  ChevronDown,
  BookOpen,
  HelpCircle,
  Bug,
  MessageSquare,
  Search,
  Check,
  AlertCircle,
  Code2,
  Zap,
} from 'lucide-react';

export default function HelpPage() {
  const [expandedFaq, setExpandedFaq] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');

  const faqs = [
    {
      id: 1,
      question: 'ما هي الصيغ المدعومة؟',
      answer: 'نحن ندعم صيغ متعددة منها: JSON، XML، CSV، YAML، و Markdown. كل صيغة لها معالج خاص يضمن دقة البيانات وسرعة المعالجة.',
    },
    {
      id: 2,
      question: 'كيف أبلّغ عن خطأ أو مشكلة؟',
      answer: 'يمكنك التبليغ عن الأخطاء مباشرة عبر نموذج البلاغ في الأسفل، أو إرسال بريد إلى support@example.com مع تفاصيل المشكلة والخطوات المؤدية إليها.',
    },
    {
      id: 3,
      question: 'ما حد الحجم الأقصى للملفات؟',
      answer: 'يمكنك رفع ملفات بحجم حتى 100 ميجابايت. للملفات الأكبر، يرجى التواصل مع فريق الدعم.',
    },
    {
      id: 4,
      question: 'هل بيانات المستخدمين محمية؟',
      answer: 'نعم، جميع البيانات مشفرة باستخدام معايير التشفير العالمية (SSL/TLS)، وتُحذف تلقائياً بعد 30 يوماً من المعالجة.',
    },
    {
      id: 5,
      question: 'كيف أستخدم واجهة برمجية التطبيقات (API)؟',
      answer: 'راجع دليل API الكامل في قسم التوثيق. يتضمن أمثلة عملية وشروحات لكل نقطة نهاية (endpoint).',
    },
  ];

  const guides = [
    {
      icon: <Code2 className="w-6 h-6" />,
      title: 'دليل الصيغ المدعومة',
      description: 'تعرّف على جميع صيغ البيانات المدعومة والمميزات الخاصة بكل صيغة.',
    },
    {
      icon: <Zap className="w-6 h-6" />,
      title: 'البدء السريع',
      description: 'خطوات بسيطة لبدء استخدام المنصة في دقائق معدودة.',
    },
    {
      icon: <BookOpen className="w-6 h-6" />,
      title: 'التوثيق الكامل',
      description: 'دليل شامل يغطي جميع المميزات والخيارات المتقدمة.',
    },
    {
      icon: <MessageSquare className="w-6 h-6" />,
      title: 'أفضل الممارسات',
      description: 'نصائح واستراتيجيات لتحقيق أقصى استفادة من الخدمة.',
    },
  ];

  const filteredFaqs = faqs.filter(
    (faq) =>
      faq.question.includes(searchTerm) ||
      faq.answer.includes(searchTerm)
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-slate-100" dir="rtl">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center gap-3 mb-4">
            <HelpCircle className="w-8 h-8 text-blue-200" />
            <h1 className="text-3xl sm:text-4xl font-bold text-white">مركز المساعدة</h1>
          </div>
          <p className="text-blue-100 text-lg">جميع ما تحتاجه لفهم واستخدام المنصة بكفاءة</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Guides Section */}
        <section className="mb-16">
          <h2 className="text-2xl font-bold mb-8 text-white flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-blue-500" />
            الأدلة والموارد
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {guides.map((guide, index) => (
              <div
                key={index}
                className="bg-slate-800 hover:bg-slate-700 rounded-lg p-6 transition-all duration-300 transform hover:scale-105 cursor-pointer border border-slate-700 hover:border-blue-500"
              >
                <div className="text-blue-500 mb-4">{guide.icon}</div>
                <h3 className="text-lg font-semibold text-white mb-2">{guide.title}</h3>
                <p className="text-slate-400 text-sm">{guide.description}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Supported Formats */}
        <section className="mb-16">
          <h2 className="text-2xl font-bold mb-8 text-white flex items-center gap-2">
            <Check className="w-6 h-6 text-green-500" />
            الصيغ المدعومة
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {['JSON', 'XML', 'CSV', 'YAML', 'Markdown', 'HTML'].map((format) => (
              <div
                key={format}
                className="bg-slate-800 border border-green-500 rounded-lg p-4 flex items-center gap-3 hover:bg-slate-700 transition-colors"
              >
                <div className="w-3 h-3 rounded-full bg-green-500"></div>
                <span className="font-semibold text-white">{format}</span>
              </div>
            ))}
          </div>
        </section>

        {/* FAQ Section */}
        <section className="mb-16">
          <h2 className="text-2xl font-bold mb-8 text-white flex items-center gap-2">
            <HelpCircle className="w-6 h-6 text-blue-500" />
            الأسئلة الشائعة
          </h2>

          {/* Search Bar */}
          <div className="mb-8 relative">
            <Search className="absolute right-4 top-3.5 w-5 h-5 text-slate-500" />
            <input
              type="text"
              placeholder="ابحث عن سؤال..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-lg py-3 pr-12 pl-4 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500 focus:ring-opacity-20 transition-all"
            />
          </div>

          {/* FAQ Items */}
          <div className="space-y-3">
            {filteredFaqs.length > 0 ? (
              filteredFaqs.map((faq) => (
                <div
                  key={faq.id}
                  className="bg-slate-800 border border-slate-700 rounded-lg overflow-hidden hover:border-blue-500 transition-colors"
                >
                  <button
                    onClick={() =>
                      setExpandedFaq(expandedFaq === faq.id ? null : faq.id)
                    }
                    className="w-full px-6 py-4 flex items-center justify-between hover:bg-slate-700 transition-colors"
                  >
                    <span className="text-lg font-semibold text-white text-right">
                      {faq.question}
                    </span>
                    <ChevronDown
                      className={`w-5 h-5 text-blue-500 transition-transform ${
                        expandedFaq === faq.id ? 'rotate-180' : ''
                      }`}
                    />
                  </button>
                  {expandedFaq === faq.id && (
                    <div className="px-6 py-4 bg-slate-900 border-t border-slate-700">
                      <p className="text-slate-300 leading-relaxed">{faq.answer}</p>
                    </div>
                  )}
                </div>
              ))
            ) : (
              <div className="bg-slate-800 border border-slate-700 rounded-lg p-8 text-center">
                <AlertCircle className="w-12 h-12 text-slate-500 mx-auto mb-4" />
                <p className="text-slate-400">لم نجد نتائج تطابق البحث</p>
              </div>
            )}
          </div>
        </section>

        {/* Report Bug Section */}
        <section>
          <h2 className="text-2xl font-bold mb-8 text-white flex items-center gap-2">
            <Bug className="w-6 h-6 text-red-500" />
            الإبلاغ عن مشكلة
          </h2>
          <div className="bg-slate-800 border border-slate-700 rounded-lg p-8">
            <form className="space-y-6">
              <div>
                <label className="block text-sm font-semibold text-white mb-2">
                  نوع المشكلة
                </label>
                <select className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500 focus:ring-opacity-20">
                  <option>خطأ في الأداء</option>
                  <option>مشكلة تقنية</option>
                  <option>طلب ميزة جديدة</option>
                  <option>أخرى</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold text-white mb-2">
                  الوصف التفصيلي
                </label>
                <textarea
                  rows="5"
                  placeholder="اشرح المشكلة بالتفصيل..."
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500 focus:ring-opacity-20 resize-none"
                ></textarea>
              </div>
              <div>
                <label className="block text-sm font-semibold text-white mb-2">
                  بريدك الإلكتروني
                </label>
                <input
                  type="email"
                  placeholder="your@email.com"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500 focus:ring-opacity-20"
                />
              </div>
              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                <Bug className="w-5 h-5" />
                إرسال البلاغ
              </button>
            </form>
          </div>
        </section>
      </div>

      {/* Footer Info */}
      <div className="bg-slate-900 border-t border-slate-800 mt-16 py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto text-center text-slate-400">
          <p>هل لم تجد الإجابة التي تبحث عنها؟</p>
          <p className="mt-2">
            <span className="text-blue-500 hover:text-blue-400 cursor-pointer font-semibold">
              تواصل مع فريق الدعم
            </span>
            {' '}أو زر{' '}
            <span className="text-blue-500 hover:text-blue-400 cursor-pointer font-semibold">
              مجتمعنا
            </span>
          </p>
        </div>
      </div>
    </div>
  );
}